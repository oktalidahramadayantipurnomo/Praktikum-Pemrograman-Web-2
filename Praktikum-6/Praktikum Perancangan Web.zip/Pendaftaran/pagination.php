<?php
include "koneksi_pendaftaran.php";

$data_per_halaman = 5;

$halaman = isset($_GET['halaman']) ? (int)$_GET['halaman'] : 1;
if ($halaman < 1) $halaman = 1;

$offset = ($halaman - 1) * $data_per_halaman;

$sql_total = mysqli_query($conn, "SELECT COUNT(*) AS total FROM pendaftar");
$total = mysqli_fetch_assoc($sql_total)['total'];

$total_halaman = ceil($total / $data_per_halaman);

$data = mysqli_query($conn,
    "SELECT * FROM pendaftar ORDER BY id ASC LIMIT $offset, $data_per_halaman"
);
?>
